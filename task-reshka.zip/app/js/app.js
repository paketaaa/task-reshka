import jQuery from 'jquery'

import Swiper from 'swiper/bundle'

import '~/app/js/parts/header.js'

$(".section-slider__swiper").each(function (index, element) {
    index++
    $(this).addClass("section-slider__swiper-" + index,)
    $(this).closest(".swiper").find(".swiper__prev").addClass("swiper__prev-" + index)
    $(this).closest(".swiper").find(".swiper__next").addClass("swiper__next-" + index)
    $(this).closest(".swiper").find(".swiper__pagination").addClass("swiper__pagination-" + index)
    const sectionSlider = new Swiper(".section-slider__swiper-" + index, {

        loop: false,
        speed: 1000,
        slidesPerView: "auto",
        navigation: true,
        allowTouchMove: true,
        watchSlidesProgress: true,
        watchSlidesVisibility: true,

        pagination: {
            el: ".swiper__pagination-" + index,
            type: "fraction",
        },
        navigation: {
            nextEl: ".swiper__next-" + index,
            prevEl: ".swiper__prev-" + index,
        },

        // breakpoints: {
        //     // when window width is >= 576px
        //     576: {
        //         slidesPerView: 2
        //     },
        //     // when window width is >= 992px
        //     992: {
        //         slidesPerView: 3
        //     },
        // }
    })
});